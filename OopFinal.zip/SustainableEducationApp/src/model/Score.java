/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author RichardBadea
 */
import javax.swing.JOptionPane;

public class Score extends GuessingGame {

    private int score;
    private String[] correctAnswers;

    public Score(String[] questions, String answers, int score, String[] correctAnswers) {
        super(questions, answers);
        score = 0;
        this.correctAnswers = correctAnswers;
    }

    public Score() {
        correctAnswers = new String[5];
        correctAnswers[0] = "34%";
        correctAnswers[1] = "More than 204 million";
        correctAnswers[2] = "Some 700 million";
        correctAnswers[3] = "12";
        correctAnswers[4] = "7";
    }

    public int getScore() {
        return score;
    }

    public void setScore(int score) {
        this.score = score;
    }

    public void computeScore(String answers, String[] questions, int score, String[] correctAnswers) {
        for (int i = 0; i < questions.length; i++) {
            for (int j = 0; j < correctAnswers.length; j++) {
                if (questions[i].equals(correctAnswers[j])) {
                    score++;
                }
            }

        }
        JOptionPane.showMessageDialog(null,"""
                                           Game over 
                                            Your score is: """ +score);

    }

}
